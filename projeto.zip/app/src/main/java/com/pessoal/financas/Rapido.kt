package com.pessoal.financas

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Bloco "Gasto" da Central de controle. */
class BlocoRapido : TileService() {
    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_ACTIVE
            label = "Gasto"
            updateTile()
        }
    }

    override fun onClick() {
        val intent = Intent(this, LancamentoRapidoActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 3, intent, PendingIntent.FLAG_IMMUTABLE)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}

/** Janelinha em sobreposição para lançar um gasto em segundos. */
class LancamentoRapidoActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val titulo = TextView(this).apply {
            text = "Novo gasto"
            textSize = 20f
        }
        val campo = EditText(this).apply {
            hint = "Ex: 45 mercado"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_DONE
            isSingleLine = true
        }
        val botao = Button(this).apply { text = "Salvar" }

        fun salvar() {
            val g = Interpretador.interpretar(campo.text.toString())
            if (g == null) {
                Toast.makeText(this, "Use algo como: 45 mercado", Toast.LENGTH_SHORT).show()
                return
            }
            Armazem.adicionar(this, g)
            val equiv = Formato.equivalencia(this, g.valor)
            Toast.makeText(
                this,
                "${Formato.moeda(g.valor)} salvo" + if (equiv.isNotEmpty()) " = $equiv" else "",
                Toast.LENGTH_LONG
            ).show()
            if (Armazem.notifAtiva(this)) Notificacao.mostrar(this)
            finish()
        }

        botao.setOnClickListener { salvar() }
        campo.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { salvar(); true } else false
        }

        raiz.addView(titulo)
        raiz.addView(campo)
        raiz.addView(botao)
        setContentView(raiz)
        window.setLayout((320 * d).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT)
        campo.requestFocus()
    }
}
