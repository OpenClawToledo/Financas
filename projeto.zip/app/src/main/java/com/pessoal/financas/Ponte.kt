package com.pessoal.financas

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

/** Monta todo o estado do app em JSON para a interface. */
object Estado {
    fun json(ctx: android.content.Context): JSONObject {
        val brutos = Armazem.gastosBrutos(ctx)
        val gastos = ArrayList<JSONObject>()
        for (i in 0 until brutos.length()) {
            val o = brutos.getJSONObject(i)
            val d = o.optString("d", "")
            gastos.add(
                JSONObject()
                    .put("q", o.getLong("q"))
                    .put("v", o.getDouble("v"))
                    .put("d", d)
                    .put("c", o.optString("c", "").ifEmpty { Categorias.detectar(d) })
                    .put("l", o.optBoolean("l", false))
                    .put("cm", o.optJSONArray("cm") ?: JSONArray())
            )
        }
        gastos.sortByDescending { it.getLong("q") }
        val arrGastos = JSONArray()
        gastos.take(1000).forEach { arrGastos.put(it) }

        val hoje = Datas.diaHoje()
        val contas = JSONArray()
        Armazem.contas(ctx).forEach { c ->
            contas.put(
                JSONObject().put("id", c.id).put("n", c.nome).put("v", c.valor).put("dia", c.dia)
                    .put("paga", Armazem.estaPaga(ctx, c.id))
                    .put("diasAte", Datas.diaEfetivo(c.dia) - hoje)
            )
        }

        val p = Previsao.doMes(ctx)
        return JSONObject()
            .put("perfil", JSONObject().put("nome", Armazem.nome(ctx)).put("parceiro", Armazem.parceiro(ctx)))
            .put("ref", JSONObject().put("cafe", Armazem.precoCafe(ctx)).put("hora", Armazem.valorHora(ctx)))
            .put("gastos", arrGastos)
            .put("contas", contas)
            .put("previsao", JSONObject().put("jaGasto", p.jaGasto).put("previsto", p.previsto)
                .put("fixasPendentes", p.fixasPendentes))
            .put("metas", Armazem.metas(ctx))
            .put("categorias", JSONArray(Categorias.todas))
            .put("inicioMes", Datas.inicioDoMes())
            .put("hoje", hoje)
            .put("diasNoMes", Datas.diasNoMes())
            .put("pagosTotal", Armazem.totalPagos(ctx))
            .put("conquistasVistas", Armazem.conquistasVistas(ctx))
            .put("notif", Armazem.notifAtiva(ctx))
    }
}

/** Ponte entre a interface (HTML/JS) e os dados nativos. Exposta no JS como window.App. */
class Ponte(private val act: MainActivity) {
    private val ctx get() = act.applicationContext

    private fun resp(ok: Boolean): String =
        JSONObject().put("ok", ok).put("estado", Estado.json(ctx)).toString()

    private fun notif() { if (Armazem.notifAtiva(ctx)) Notificacao.mostrar(ctx) }

    @JavascriptInterface fun estado(): String = Estado.json(ctx).toString()

    @JavascriptInterface fun adicionarGasto(texto: String, categoria: String): String {
        val g = Interpretador.interpretar(texto) ?: return resp(false)
        Armazem.adicionar(ctx, if (categoria.isNotBlank()) g.copy(categoria = categoria) else g)
        notif()
        return resp(true)
    }

    @JavascriptInterface fun removerGasto(q: String): String {
        Armazem.remover(ctx, q.toLong()); notif(); return resp(true)
    }

    @JavascriptInterface fun restaurarGasto(q: String, valor: Double, desc: String, cat: String): String {
        Armazem.adicionar(ctx, Gasto(q.toLong(), valor, desc, cat)); notif(); return resp(true)
    }

    @JavascriptInterface fun mudarCategoria(q: String, cat: String): String {
        Armazem.mudarCategoria(ctx, q.toLong(), cat); return resp(true)
    }

    @JavascriptInterface fun curtir(q: String): String {
        Armazem.curtir(ctx, q.toLong()); return resp(true)
    }

    @JavascriptInterface fun comentar(q: String, texto: String): String {
        if (texto.isBlank()) return resp(false)
        Armazem.comentar(ctx, q.toLong(), Armazem.nome(ctx), texto.trim()); return resp(true)
    }

    @JavascriptInterface fun adicionarConta(nome: String, valor: String, dia: String): String {
        val v = Interpretador.paraNumero(valor)
        val d = dia.trim().toIntOrNull()
        if (nome.isBlank() || v == null || v <= 0 || d == null || d !in 1..31) return resp(false)
        Armazem.adicionarConta(ctx, ContaFixa(System.currentTimeMillis(), nome.trim(), v, d))
        notif()
        return resp(true)
    }

    @JavascriptInterface fun removerConta(id: String): String {
        Armazem.removerConta(ctx, id.toLong()); notif(); return resp(true)
    }

    @JavascriptInterface fun alternarPaga(id: String): String {
        val c = Armazem.contas(ctx).firstOrNull { it.id == id.toLong() } ?: return resp(false)
        if (Armazem.estaPaga(ctx, c.id)) Armazem.desmarcarPaga(ctx, c) else Armazem.marcarPaga(ctx, c)
        notif()
        return resp(true)
    }

    @JavascriptInterface fun adicionarMeta(nome: String, alvo: String, emoji: String): String {
        val a = Interpretador.paraNumero(alvo)
        if (nome.isBlank() || a == null || a <= 0) return resp(false)
        Armazem.adicionarMeta(ctx, nome.trim(), a, emoji.ifBlank { "🎯" })
        return resp(true)
    }

    @JavascriptInterface fun aportarMeta(id: String, valor: String): String {
        val v = Interpretador.paraNumero(valor.replace("-", "")) ?: return resp(false)
        val sinal = if (valor.trim().startsWith("-")) -1 else 1
        Armazem.aportarMeta(ctx, id.toLong(), v * sinal)
        return resp(true)
    }

    @JavascriptInterface fun removerMeta(id: String): String {
        Armazem.removerMeta(ctx, id.toLong()); return resp(true)
    }

    @JavascriptInterface fun salvarPerfil(nome: String, parceiro: String): String {
        Armazem.salvarPerfil(ctx, nome.trim(), parceiro.trim()); return resp(true)
    }

    @JavascriptInterface fun salvarReferencias(cafe: String, hora: String): String {
        Armazem.salvarReferencias(ctx, Interpretador.paraNumero(cafe) ?: 0.0, Interpretador.paraNumero(hora) ?: 0.0)
        notif()
        return resp(true)
    }

    @JavascriptInterface fun marcarConquista(id: String) { Armazem.marcarConquista(ctx, id) }

    @JavascriptInterface fun ativarNotificacao() { act.runOnUiThread { act.ativarNotificacao() } }

    @JavascriptInterface fun vibrar() { act.vibrar() }
}
