package com.pessoal.financas

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/** A interface é uma página HTML local (assets/index.html) com ponte para os dados nativos. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val fundo = Color.parseColor("#0E0F13")
        window.statusBarColor = fundo
        window.navigationBarColor = fundo

        web = WebView(this).apply {
            setBackgroundColor(fundo)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            overScrollMode = WebView.OVER_SCROLL_NEVER
            webViewClient = WebViewClient()
            addJavascriptInterface(Ponte(this@MainActivity), "App")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        Lembretes.agendar(this)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.recarregar && recarregar()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.voltar ? voltar() : false") { r ->
            if (r != "true") finish()
        }
    }

    fun vibrar() = runOnUiThread { web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    fun ativarNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        } else {
            ligarNotificacao()
        }
    }

    private fun ligarNotificacao() {
        Armazem.definirNotifAtiva(this, true)
        Notificacao.mostrar(this)
        web.evaluateJavascript("window.recarregar && recarregar()", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 10) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) ligarNotificacao()
        else Toast.makeText(this, "Sem permissão de notificação", Toast.LENGTH_LONG).show()
    }
}
