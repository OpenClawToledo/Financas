package com.pessoal.financas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var total: TextView
    private lateinit var equivalencia: TextView
    private lateinit var conteudo: LinearLayout
    private lateinit var abas: List<Button>
    private var abaAtual = 0
    private var dp = 1f
    private val verde = Color.parseColor("#1B7F5A")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dp = resources.displayMetrics.density
        val pad = px(16)

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        total = TextView(this).apply { textSize = 28f; setTypeface(typeface, Typeface.BOLD) }
        equivalencia = TextView(this).apply { textSize = 14f; alpha = 0.8f }

        val barraAbas = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, pad, 0, pad / 2)
        }
        abas = listOf("Resumo", "Lançamentos", "Contas").mapIndexed { i, nome ->
            Button(this).apply {
                text = nome
                isAllCaps = false
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { abaAtual = i; atualizar() }
            }
        }
        abas.forEach { barraAbas.addView(it) }

        conteudo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        raiz.addView(total)
        raiz.addView(equivalencia)
        raiz.addView(barraAbas)
        raiz.addView(conteudo)
        setContentView(ScrollView(this).apply { addView(raiz) })

        Lembretes.agendar(this)
    }

    override fun onResume() {
        super.onResume()
        atualizar()
    }

    // ---------- utilidades de layout ----------
    private fun px(v: Int) = (v * dp).toInt()

    private fun titulo(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, px(18), 0, px(6))
    }

    private fun texto(t: String, tamanho: Float = 15f, opacidade: Float = 1f) = TextView(this).apply {
        text = t
        textSize = tamanho
        alpha = opacidade
        setPadding(0, px(4), 0, px(4))
    }

    private fun campo(dica: String, numerico: Boolean = false) = EditText(this).apply {
        hint = dica
        isSingleLine = true
        inputType = if (numerico) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        else InputType.TYPE_CLASS_TEXT
    }

    private fun botao(t: String, acao: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { acao() }
    }

    private fun barra(fracao: Double): View {
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(10))
            background = GradientDrawable().apply {
                cornerRadius = px(5).toFloat(); setColor(Color.argb(40, 27, 127, 90))
            }
        }
        val f = fracao.coerceIn(0.0, 1.0).toFloat()
        linha.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, f)
            background = GradientDrawable().apply { cornerRadius = px(5).toFloat(); setColor(verde) }
        })
        linha.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f - f)
        })
        return linha
    }

    private fun numeroParaTexto(v: Double): String =
        if (v <= 0) "" else String.format(Locale("pt", "BR"), "%.2f", v)

    // ---------- telas ----------
    private fun atualizar() {
        val t = Armazem.totalDoMes(this)
        total.text = "Este mês: " + Formato.moeda(t)
        val eq = Formato.equivalencia(this, t)
        equivalencia.text = if (eq.isNotEmpty()) "= $eq" else ""
        abas.forEachIndexed { i, b -> b.alpha = if (i == abaAtual) 1f else 0.5f }

        conteudo.removeAllViews()
        when (abaAtual) {
            0 -> telaResumo()
            1 -> telaLancamentos()
            else -> telaContas()
        }
    }

    private fun telaResumo() {
        val entrada = campo("Ex: 45 mercado")
        conteudo.addView(entrada)
        conteudo.addView(botao("Adicionar gasto") {
            val g = Interpretador.interpretar(entrada.text.toString())
            if (g == null) {
                Toast.makeText(this, "Use algo como: 45 mercado", Toast.LENGTH_SHORT).show()
            } else {
                Armazem.adicionar(this, g)
                Toast.makeText(this, "Salvo em ${g.categoria}", Toast.LENGTH_SHORT).show()
                atualizar()
            }
        })

        // Previsão
        val p = Previsao.doMes(this)
        conteudo.addView(titulo("Previsão do mês"))
        conteudo.addView(texto("Deve fechar em torno de ${Formato.moeda(p.previsto)}", 16f))
        conteudo.addView(texto(
            "Já gasto ${Formato.moeda(p.jaGasto)} · contas fixas pendentes ${Formato.moeda(p.fixasPendentes)}",
            13f, 0.75f
        ))
        if (Datas.diaHoje() <= 5) {
            conteudo.addView(texto("A estimativa fica mais precisa depois dos primeiros dias do mês.", 12f, 0.6f))
        }

        // Próximas contas
        val proximas = Previsao.proximasContas(this).take(4)
        if (proximas.isNotEmpty()) {
            conteudo.addView(titulo("Próximas contas"))
            proximas.forEach { (c, d) ->
                conteudo.addView(texto("${c.nome}  ${Formato.moeda(c.valor)}  — ${Formato.prazo(d)}").apply {
                    if (d < 0) setTextColor(Color.parseColor("#C0392B"))
                })
            }
        }

        // Gastos por categoria
        val porCategoria = Armazem.gastosDoMes(this)
            .groupBy { it.categoria }
            .mapValues { e -> e.value.sumOf { it.valor } }
            .toList().sortedByDescending { it.second }
        if (porCategoria.isNotEmpty()) {
            conteudo.addView(titulo("Por categoria"))
            val maior = porCategoria.first().second
            porCategoria.forEach { (cat, v) ->
                conteudo.addView(texto("$cat  ${Formato.moeda(v)}", 14f))
                conteudo.addView(barra(if (maior > 0) v / maior else 0.0))
            }
        }

        // Notificação e dicas
        conteudo.addView(titulo("Lançamento rápido"))
        conteudo.addView(botao("Ativar notificação fixa") { ativarNotificacao() })
        conteudo.addView(texto(
            "Na Central de controle, toque no lápis e adicione o bloco \"Gasto\".", 13f, 0.7f
        ))

        // Referências
        conteudo.addView(titulo("Referências para equivalência"))
        val cafe = campo("Preço de um café da manhã (R$)", true).apply {
            setText(numeroParaTexto(Armazem.precoCafe(context)))
        }
        val hora = campo("Seu valor por hora de trabalho (R$)", true).apply {
            setText(numeroParaTexto(Armazem.valorHora(context)))
        }
        conteudo.addView(cafe)
        conteudo.addView(hora)
        conteudo.addView(botao("Salvar referências") {
            Armazem.salvarReferencias(
                this,
                Interpretador.paraNumero(cafe.text.toString()) ?: 0.0,
                Interpretador.paraNumero(hora.text.toString()) ?: 0.0
            )
            Toast.makeText(this, "Salvo", Toast.LENGTH_SHORT).show()
            atualizar()
        })
    }

    private fun telaLancamentos() {
        conteudo.addView(texto("Toque para mudar a categoria · segure para apagar", 13f, 0.7f))
        val gastos = Armazem.listar(this).take(200)
        if (gastos.isEmpty()) conteudo.addView(texto("Nenhum lançamento ainda.", 14f, 0.7f))
        gastos.forEach { g ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, px(8), 0, px(8))
            }
            item.addView(texto("${Formato.moeda(g.valor)}   ${g.descricao}", 15f).apply { setPadding(0, 0, 0, 0) })
            item.addView(texto("${Formato.data(g.quando)} · ${g.categoria}", 12f, 0.65f).apply { setPadding(0, 0, 0, 0) })
            item.setOnClickListener {
                val cats = Categorias.todas.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Categoria")
                    .setItems(cats) { _, i ->
                        Armazem.mudarCategoria(this, g.quando, cats[i])
                        atualizar()
                    }
                    .show()
            }
            item.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setMessage("Apagar ${Formato.moeda(g.valor)} ${g.descricao}?")
                    .setPositiveButton("Apagar") { _, _ -> Armazem.remover(this, g.quando); atualizar() }
                    .setNegativeButton("Cancelar", null)
                    .show()
                true
            }
            conteudo.addView(item)
        }
    }

    private fun telaContas() {
        val contas = Armazem.contas(this)
        val totalFixas = contas.sumOf { it.valor }
        conteudo.addView(texto("Total de contas fixas: ${Formato.moeda(totalFixas)}/mês", 16f))
        val eq = Formato.equivalencia(this, totalFixas)
        if (eq.isNotEmpty()) conteudo.addView(texto("= $eq por mês", 13f, 0.75f))
        conteudo.addView(texto("Toque para marcar como paga · segure para excluir", 13f, 0.7f))

        val hoje = Datas.diaHoje()
        contas.forEach { c ->
            val paga = Armazem.estaPaga(this, c.id)
            val dias = Datas.diaEfetivo(c.dia) - hoje
            val status = if (paga) "✓ paga" else Formato.prazo(dias)
            val item = texto("${c.nome}  ${Formato.moeda(c.valor)}  · dia ${c.dia} · $status").apply {
                setPadding(0, px(10), 0, px(10))
                if (paga) alpha = 0.55f
                else if (dias < 0) setTextColor(Color.parseColor("#C0392B"))
                setOnClickListener {
                    if (paga) Armazem.desmarcarPaga(this@MainActivity, c)
                    else Armazem.marcarPaga(this@MainActivity, c)
                    Notificacao.mostrar(this@MainActivity)
                    atualizar()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("Excluir a conta fixa ${c.nome}?")
                        .setPositiveButton("Excluir") { _, _ -> Armazem.removerConta(this@MainActivity, c.id); atualizar() }
                        .setNegativeButton("Cancelar", null)
                        .show()
                    true
                }
            }
            conteudo.addView(item)
        }

        conteudo.addView(titulo("Nova conta fixa"))
        val nome = campo("Nome (ex: Luz, Aluguel, Internet)")
        val valor = campo("Valor (R$)", true)
        val dia = campo("Dia do vencimento (1 a 31)").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        conteudo.addView(nome)
        conteudo.addView(valor)
        conteudo.addView(dia)
        conteudo.addView(botao("Adicionar conta fixa") {
            val n = nome.text.toString().trim()
            val v = Interpretador.paraNumero(valor.text.toString())
            val d = dia.text.toString().toIntOrNull()
            if (n.isEmpty() || v == null || v <= 0 || d == null || d !in 1..31) {
                Toast.makeText(this, "Preencha nome, valor e dia (1 a 31)", Toast.LENGTH_SHORT).show()
            } else {
                Armazem.adicionarConta(this, ContaFixa(System.currentTimeMillis(), n, v, d))
                atualizar()
            }
        }.apply { gravity = Gravity.CENTER })
    }

    // ---------- notificação ----------
    private fun ativarNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        } else {
            Notificacao.mostrar(this)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 10) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) Notificacao.mostrar(this)
        else Toast.makeText(this, "Sem permissão de notificação", Toast.LENGTH_LONG).show()
    }
}
