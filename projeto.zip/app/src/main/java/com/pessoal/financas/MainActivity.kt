package com.pessoal.financas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var total: TextView
    private lateinit var equivalencia: TextView
    private lateinit var lista: LinearLayout
    private var dp = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        total = TextView(this).apply { textSize = 30f }
        equivalencia = TextView(this).apply { textSize = 15f; alpha = 0.8f }

        val campo = EditText(this).apply {
            hint = "Ex: 45 mercado"
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
        }
        val adicionar = Button(this).apply {
            text = "Adicionar gasto"
            setOnClickListener {
                val g = Interpretador.interpretar(campo.text.toString())
                if (g == null) {
                    Toast.makeText(context, "Use algo como: 45 mercado", Toast.LENGTH_SHORT).show()
                } else {
                    Armazem.adicionar(context, g)
                    campo.setText("")
                    atualizar()
                }
            }
        }

        val ativarNotif = Button(this).apply {
            text = "Ativar notificação de lançamento rápido"
            setOnClickListener { ativarNotificacao() }
        }

        val dica = TextView(this).apply {
            text = "Dica: na Central de controle, toque em editar e adicione o bloco \"Gasto\"."
            textSize = 13f
            alpha = 0.7f
            setPadding(0, pad / 2, 0, pad)
        }

        val refTitulo = TextView(this).apply { text = "Referências para equivalência"; textSize = 16f }
        val cafe = EditText(this).apply {
            hint = "Preço de um café da manhã (R$)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(numeroParaTexto(Armazem.precoCafe(context)))
        }
        val hora = EditText(this).apply {
            hint = "Seu valor por hora de trabalho (R$)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(numeroParaTexto(Armazem.valorHora(context)))
        }
        val salvarRef = Button(this).apply {
            text = "Salvar referências"
            setOnClickListener {
                Armazem.salvarReferencias(
                    context,
                    Interpretador.paraNumero(cafe.text.toString()) ?: 0.0,
                    Interpretador.paraNumero(hora.text.toString()) ?: 0.0
                )
                atualizar()
                Toast.makeText(context, "Salvo", Toast.LENGTH_SHORT).show()
            }
        }

        val listaTitulo = TextView(this).apply {
            text = "Lançamentos (segure para apagar)"
            textSize = 16f
            setPadding(0, pad, 0, pad / 2)
        }
        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        listOf<View>(total, equivalencia, campo, adicionar, ativarNotif, dica,
            refTitulo, cafe, hora, salvarRef, listaTitulo, lista).forEach { raiz.addView(it) }

        setContentView(ScrollView(this).apply { addView(raiz) })
    }

    override fun onResume() {
        super.onResume()
        atualizar()
    }

    private fun numeroParaTexto(v: Double): String =
        if (v <= 0) "" else String.format(java.util.Locale("pt", "BR"), "%.2f", v)

    private fun atualizar() {
        val t = Armazem.totalDoMes(this)
        total.text = "Este mês: " + Formato.moeda(t)
        val eq = Formato.equivalencia(this, t)
        equivalencia.text = if (eq.isNotEmpty()) "= $eq" else ""

        lista.removeAllViews()
        Armazem.listar(this).take(100).forEach { g ->
            val item = TextView(this).apply {
                text = "${Formato.data(g.quando)}   ${Formato.moeda(g.valor)}   ${g.descricao}"
                textSize = 15f
                setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
                setOnLongClickListener {
                    AlertDialog.Builder(context)
                        .setMessage("Apagar ${Formato.moeda(g.valor)} ${g.descricao}?")
                        .setPositiveButton("Apagar") { _, _ ->
                            Armazem.remover(context, g.quando)
                            atualizar()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                    true
                }
            }
            lista.addView(item)
        }
    }

    private fun ativarNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        } else {
            Notificacao.mostrar(this)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            Notificacao.mostrar(this)
        } else if (requestCode == 10) {
            Toast.makeText(this, "Sem permissão de notificação", Toast.LENGTH_LONG).show()
        }
    }
}
