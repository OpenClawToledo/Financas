package com.pessoal.financas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Gasto(val quando: Long, val valor: Double, val descricao: String, val categoria: String)
data class ContaFixa(val id: Long, val nome: String, val valor: Double, val dia: Int)

/** Categorias com detecção automática pela descrição. */
object Categorias {
    const val FIXAS = "Contas fixas"
    const val OUTROS = "Outros"

    // A ordem importa: termos mais específicos primeiro ("mercado livre" antes de "mercado")
    private val regras = listOf(
        "Compras" to listOf("mercado livre", "shopee", "amazon", "shein", "aliexpress", "roupa", "loja", "tenis", "presente"),
        "Mercado" to listOf("supermercado", "mercado", "feira", "hortifruti", "atacad", "acougue", "sacolao"),
        "Alimentação" to listOf("almoco", "jantar", "lanche", "cafe", "restaurante", "ifood", "pizza", "hamburg", "padaria", "bar", "sorvete"),
        "Transporte" to listOf("uber", "gasolina", "combustivel", "posto", "onibus", "metro", "estacionamento", "pedagio", "oficina"),
        "Moradia" to listOf("aluguel", "condominio", "luz", "energia", "agua", "gas", "internet", "reforma"),
        "Saúde" to listOf("farmacia", "remedio", "medico", "consulta", "exame", "academia", "dentista"),
        "Lazer" to listOf("cinema", "show", "viagem", "netflix", "spotify", "jogo", "passeio", "festa"),
        "Educação" to listOf("curso", "livro", "escola", "faculdade", "apostila")
    )

    val todas: List<String> = regras.map { it.first } + listOf(FIXAS, OUTROS)

    private fun normalizar(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    fun detectar(descricao: String): String {
        val d = normalizar(descricao)
        for ((cat, palavras) in regras) if (palavras.any { d.contains(it) }) return cat
        return OUTROS
    }
}

object Armazem {
    private const val PREFS = "financas"
    private const val KEY_GASTOS = "gastos"
    private const val KEY_CONTAS = "contas"
    private const val KEY_PAGOS = "pagos"
    private const val KEY_CAFE = "preco_cafe"
    private const val KEY_HORA = "valor_hora"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun ler(ctx: Context, chave: String): JSONArray =
        try { JSONArray(prefs(ctx).getString(chave, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }

    private fun gravar(ctx: Context, chave: String, arr: JSONArray) {
        prefs(ctx).edit().putString(chave, arr.toString()).commit()
    }

    // ---------- Gastos ----------
    fun listar(ctx: Context): List<Gasto> {
        val arr = ler(ctx, KEY_GASTOS)
        val lista = ArrayList<Gasto>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.optString("d", "")
            val c = o.optString("c", "").ifEmpty { Categorias.detectar(d) }
            lista.add(Gasto(o.getLong("q"), o.getDouble("v"), d, c))
        }
        return lista.sortedByDescending { it.quando }
    }

    fun adicionar(ctx: Context, g: Gasto) {
        val arr = ler(ctx, KEY_GASTOS)
        arr.put(JSONObject().put("q", g.quando).put("v", g.valor).put("d", g.descricao).put("c", g.categoria))
        gravar(ctx, KEY_GASTOS, arr)
    }

    fun remover(ctx: Context, quando: Long) {
        val arr = ler(ctx, KEY_GASTOS)
        val novo = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("q") != quando) novo.put(o)
        }
        gravar(ctx, KEY_GASTOS, novo)
    }

    fun mudarCategoria(ctx: Context, quando: Long, categoria: String) {
        val arr = ler(ctx, KEY_GASTOS)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("q") == quando) o.put("c", categoria)
        }
        gravar(ctx, KEY_GASTOS, arr)
    }

    fun gastosDoMes(ctx: Context): List<Gasto> {
        val inicio = Datas.inicioDoMes()
        return listar(ctx).filter { it.quando >= inicio }
    }

    fun totalDoMes(ctx: Context): Double = gastosDoMes(ctx).sumOf { it.valor }

    // ---------- Contas fixas ----------
    fun contas(ctx: Context): List<ContaFixa> {
        val arr = ler(ctx, KEY_CONTAS)
        val lista = ArrayList<ContaFixa>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            lista.add(ContaFixa(o.getLong("id"), o.getString("n"), o.getDouble("v"), o.getInt("dia")))
        }
        return lista.sortedBy { it.dia }
    }

    fun adicionarConta(ctx: Context, c: ContaFixa) {
        val arr = ler(ctx, KEY_CONTAS)
        arr.put(JSONObject().put("id", c.id).put("n", c.nome).put("v", c.valor).put("dia", c.dia))
        gravar(ctx, KEY_CONTAS, arr)
    }

    fun removerConta(ctx: Context, id: Long) {
        val arr = ler(ctx, KEY_CONTAS)
        val novo = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("id") != id) novo.put(o)
        }
        gravar(ctx, KEY_CONTAS, novo)
    }

    private fun chavePago(id: Long) = Datas.mesAtual() + ":" + id

    fun estaPaga(ctx: Context, id: Long): Boolean {
        val arr = ler(ctx, KEY_PAGOS)
        val k = chavePago(id)
        for (i in 0 until arr.length()) if (arr.getString(i) == k) return true
        return false
    }

    /** Marcar como paga também lança o gasto, para entrar no total do mês. */
    fun marcarPaga(ctx: Context, c: ContaFixa) {
        if (estaPaga(ctx, c.id)) return
        val arr = ler(ctx, KEY_PAGOS)
        arr.put(chavePago(c.id))
        gravar(ctx, KEY_PAGOS, arr)
        adicionar(ctx, Gasto(System.currentTimeMillis(), c.valor, c.nome, Categorias.FIXAS))
    }

    fun desmarcarPaga(ctx: Context, c: ContaFixa) {
        val arr = ler(ctx, KEY_PAGOS)
        val k = chavePago(c.id)
        val novo = JSONArray()
        for (i in 0 until arr.length()) if (arr.getString(i) != k) novo.put(arr.getString(i))
        gravar(ctx, KEY_PAGOS, novo)
        // remove o lançamento correspondente deste mês
        gastosDoMes(ctx).firstOrNull { it.categoria == Categorias.FIXAS && it.descricao == c.nome }
            ?.let { remover(ctx, it.quando) }
    }

    // ---------- Social: curtidas e comentários ----------
    fun gastosBrutos(ctx: Context): JSONArray = ler(ctx, KEY_GASTOS)

    fun curtir(ctx: Context, quando: Long) {
        val arr = ler(ctx, KEY_GASTOS)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("q") == quando) o.put("l", !o.optBoolean("l", false))
        }
        gravar(ctx, KEY_GASTOS, arr)
    }

    fun comentar(ctx: Context, quando: Long, autor: String, texto: String) {
        val arr = ler(ctx, KEY_GASTOS)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("q") == quando) {
                val cm = o.optJSONArray("cm") ?: JSONArray()
                cm.put(JSONObject().put("a", autor).put("t", texto).put("q", System.currentTimeMillis()))
                o.put("cm", cm)
            }
        }
        gravar(ctx, KEY_GASTOS, arr)
    }

    fun totalPagos(ctx: Context): Int = ler(ctx, KEY_PAGOS).length()

    // ---------- Metas ----------
    fun metas(ctx: Context): JSONArray = ler(ctx, "metas")

    fun adicionarMeta(ctx: Context, nome: String, alvo: Double, emoji: String) {
        val arr = ler(ctx, "metas")
        arr.put(JSONObject().put("id", System.currentTimeMillis()).put("n", nome)
            .put("alvo", alvo).put("atual", 0.0).put("e", emoji))
        gravar(ctx, "metas", arr)
    }

    fun aportarMeta(ctx: Context, id: Long, valor: Double) {
        val arr = ler(ctx, "metas")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("id") == id) o.put("atual", maxOf(0.0, o.optDouble("atual", 0.0) + valor))
        }
        gravar(ctx, "metas", arr)
    }

    fun removerMeta(ctx: Context, id: Long) {
        val arr = ler(ctx, "metas")
        val novo = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("id") != id) novo.put(o)
        }
        gravar(ctx, "metas", novo)
    }

    // ---------- Perfil e conquistas ----------
    fun nome(ctx: Context): String = prefs(ctx).getString("nome", "Eu") ?: "Eu"
    fun parceiro(ctx: Context): String = prefs(ctx).getString("parceiro", "") ?: ""
    fun salvarPerfil(ctx: Context, nome: String, parceiro: String) {
        prefs(ctx).edit().putString("nome", nome.ifBlank { "Eu" }).putString("parceiro", parceiro).commit()
    }

    fun conquistasVistas(ctx: Context): JSONArray = ler(ctx, "conquistas")
    fun marcarConquista(ctx: Context, id: String) {
        val arr = ler(ctx, "conquistas")
        for (i in 0 until arr.length()) if (arr.getString(i) == id) return
        arr.put(id)
        gravar(ctx, "conquistas", arr)
    }

    fun notifAtiva(ctx: Context): Boolean = prefs(ctx).getBoolean("notif", false)
    fun definirNotifAtiva(ctx: Context, v: Boolean) { prefs(ctx).edit().putBoolean("notif", v).commit() }

    // ---------- Referências ----------
    fun precoCafe(ctx: Context): Double = prefs(ctx).getFloat(KEY_CAFE, 15f).toDouble()
    fun valorHora(ctx: Context): Double = prefs(ctx).getFloat(KEY_HORA, 0f).toDouble()

    fun salvarReferencias(ctx: Context, cafe: Double, hora: Double) {
        prefs(ctx).edit().putFloat(KEY_CAFE, cafe.toFloat()).putFloat(KEY_HORA, hora.toFloat()).commit()
    }
}

object Datas {
    fun inicioDoMes(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun mesAtual(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    fun diaHoje(): Int = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    fun diasNoMes(): Int = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH)

    /** Dia de vencimento efetivo (conta no dia 31 vence no último dia em meses curtos). */
    fun diaEfetivo(dia: Int): Int = minOf(dia, diasNoMes())
}

/** Previsão do mês: o que já foi gasto + projeção do ritmo atual + contas fixas ainda não pagas. */
object Previsao {
    data class Resultado(val jaGasto: Double, val previsto: Double, val fixasPendentes: Double)

    fun doMes(ctx: Context): Resultado {
        val gastos = Armazem.gastosDoMes(ctx)
        val jaGasto = gastos.sumOf { it.valor }
        val variavel = gastos.filter { it.categoria != Categorias.FIXAS }.sumOf { it.valor }
        val hoje = Datas.diaHoje()
        val projVariavel = variavel / hoje * Datas.diasNoMes()
        val fixasPendentes = Armazem.contas(ctx).filter { !Armazem.estaPaga(ctx, it.id) }.sumOf { it.valor }
        val fixasPagas = jaGasto - variavel
        return Resultado(jaGasto, projVariavel + fixasPagas + fixasPendentes, fixasPendentes)
    }

    /** Contas ainda não pagas neste mês, com dias até o vencimento (negativo = atrasada). */
    fun proximasContas(ctx: Context): List<Pair<ContaFixa, Int>> {
        val hoje = Datas.diaHoje()
        return Armazem.contas(ctx)
            .filter { !Armazem.estaPaga(ctx, it.id) }
            .map { it to (Datas.diaEfetivo(it.dia) - hoje) }
            .sortedBy { it.second }
    }
}

/** Entende textos como "45 mercado", "mercado 45,90" ou "1.250,00 aluguel". */
object Interpretador {
    private val numero = Regex("""\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?(?!\d)|\d+(?:[.,]\d{1,2})?(?!\d)""")
    private val milhar = Regex("""\d{1,3}(?:\.\d{3})+""")

    fun paraNumero(s: String): Double? {
        var x = s.trim()
        if (x.contains(',')) x = x.replace(".", "").replace(',', '.')
        else if (milhar.matches(x)) x = x.replace(".", "")
        return x.toDoubleOrNull()
    }

    fun interpretar(texto: String): Gasto? {
        val t = texto.trim()
        val m = numero.find(t) ?: return null
        val valor = paraNumero(m.value) ?: return null
        if (valor <= 0) return null
        val desc = t.removeRange(m.range).trim().ifEmpty { "Sem descrição" }
        return Gasto(System.currentTimeMillis(), valor, desc, Categorias.detectar(desc))
    }
}

object Formato {
    private val br = Locale("pt", "BR")
    fun moeda(v: Double): String = NumberFormat.getCurrencyInstance(br).format(v)
    fun data(ms: Long): String = SimpleDateFormat("dd/MM HH:mm", br).format(Date(ms))

    fun prazo(dias: Int): String = when {
        dias < 0 -> "atrasada ${-dias} dia(s)"
        dias == 0 -> "vence hoje"
        dias == 1 -> "vence amanhã"
        else -> "vence em $dias dias"
    }

    /** O diferencial: traduz dinheiro em coisas da vida real. */
    fun equivalencia(ctx: Context, valor: Double): String {
        val partes = mutableListOf<String>()
        val cafe = Armazem.precoCafe(ctx)
        if (cafe > 0) partes += String.format(br, "%.1f cafés da manhã", valor / cafe)
        val hora = Armazem.valorHora(ctx)
        if (hora > 0) partes += String.format(br, "%.1f h de trabalho", valor / hora)
        return partes.joinToString(" · ")
    }
}
