package com.pessoal.financas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Gasto(val quando: Long, val valor: Double, val descricao: String)

/** Armazenamento local simples (v0.1). Depois migra para banco + sincronização do casal. */
object Armazem {
    private const val PREFS = "financas"
    private const val KEY_GASTOS = "gastos"
    private const val KEY_CAFE = "preco_cafe"
    private const val KEY_HORA = "valor_hora"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun lerArray(ctx: Context): JSONArray =
        try { JSONArray(prefs(ctx).getString(KEY_GASTOS, "[]") ?: "[]") } catch (e: Exception) { JSONArray() }

    fun listar(ctx: Context): List<Gasto> {
        val arr = lerArray(ctx)
        val lista = ArrayList<Gasto>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            lista.add(Gasto(o.getLong("q"), o.getDouble("v"), o.optString("d", "")))
        }
        return lista.sortedByDescending { it.quando }
    }

    fun adicionar(ctx: Context, g: Gasto) {
        val arr = lerArray(ctx)
        arr.put(JSONObject().put("q", g.quando).put("v", g.valor).put("d", g.descricao))
        prefs(ctx).edit().putString(KEY_GASTOS, arr.toString()).commit()
    }

    fun remover(ctx: Context, quando: Long) {
        val arr = lerArray(ctx)
        val novo = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("q") != quando) novo.put(o)
        }
        prefs(ctx).edit().putString(KEY_GASTOS, novo.toString()).commit()
    }

    fun totalDoMes(ctx: Context): Double {
        val c = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val inicio = c.timeInMillis
        return listar(ctx).filter { it.quando >= inicio }.sumOf { it.valor }
    }

    fun precoCafe(ctx: Context): Double = prefs(ctx).getFloat(KEY_CAFE, 15f).toDouble()
    fun valorHora(ctx: Context): Double = prefs(ctx).getFloat(KEY_HORA, 0f).toDouble()

    fun salvarReferencias(ctx: Context, cafe: Double, hora: Double) {
        prefs(ctx).edit().putFloat(KEY_CAFE, cafe.toFloat()).putFloat(KEY_HORA, hora.toFloat()).commit()
    }
}

/** Entende textos como "45 mercado", "mercado 45,90" ou "1.250,00 aluguel". */
object Interpretador {
    private val numero = Regex("""\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?(?!\d)|\d+(?:[.,]\d{1,2})?(?!\d)""")
    private val milhar = Regex("""\d{1,3}(?:\.\d{3})+""")

    fun paraNumero(s: String): Double? {
        var x = s.trim()
        if (x.contains(',')) x = x.replace(".", "").replace(',', '.')
        else if (milhar.matches(x)) x = x.replace(".", "")
        return x.toDoubleOrNull()
    }

    fun interpretar(texto: String): Gasto? {
        val t = texto.trim()
        val m = numero.find(t) ?: return null
        val valor = paraNumero(m.value) ?: return null
        if (valor <= 0) return null
        val desc = t.removeRange(m.range).trim().ifEmpty { "Sem descrição" }
        return Gasto(System.currentTimeMillis(), valor, desc)
    }
}

object Formato {
    private val br = Locale("pt", "BR")
    fun moeda(v: Double): String = NumberFormat.getCurrencyInstance(br).format(v)
    fun data(ms: Long): String = SimpleDateFormat("dd/MM HH:mm", br).format(Date(ms))

    /** O diferencial: traduz dinheiro em coisas da vida real. */
    fun equivalencia(ctx: Context, valor: Double): String {
        val partes = mutableListOf<String>()
        val cafe = Armazem.precoCafe(ctx)
        if (cafe > 0) partes += String.format(br, "%.1f cafés da manhã", valor / cafe)
        val hora = Armazem.valorHora(ctx)
        if (hora > 0) partes += String.format(br, "%.1f h de trabalho", valor / hora)
        return partes.joinToString(" · ")
    }
}
