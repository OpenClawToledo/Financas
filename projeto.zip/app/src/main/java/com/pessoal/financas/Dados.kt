package com.pessoal.financas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Currency
import java.util.Date
import java.util.Locale

/** Resultado do interpretador de texto: despesa (receita = false) ou entrada de dinheiro. */
data class Gasto(
    val quando: Long,
    val valor: Double,
    val descricao: String,
    val categoria: String,
    val receita: Boolean = false
)

data class Lanc(val id: String, val q: Long, val v: Double, val d: String, val c: String, val receita: Boolean, val sh: Boolean, val dono: String, val cf: String)
data class ContaFixa(val id: String, val nome: String, val valor: Double, val dia: Int, val entrada: Boolean, val sh: Boolean, val dono: String)
data class Meta(val id: String, val nome: String, val alvo: Double, val emoji: String, val tipo: String, val sh: Boolean, val dono: String, val atual: Double)

/** Categorias com detecção automática pela descrição. */
object Categorias {
    const val FIXAS = "Contas fixas"
    const val OUTROS = "Outros"
    const val SALARIO = "Salário"
    const val EXTRA = "Extra"

    // A ordem importa: termos mais específicos primeiro ("mercado livre" antes de "mercado")
    private val regras = listOf(
        "Compras" to listOf("mercado livre", "shopee", "amazon", "shein", "aliexpress", "roupa", "loja", "tenis", "presente", "worten", "fnac"),
        "Mercado" to listOf("supermercado", "mercado", "feira", "hortifruti", "atacad", "acougue", "talho", "continente", "pingo doce", "lidl", "aldi", "minipreco", "intermarche", "mercearia"),
        "Alimentação" to listOf("almoco", "jantar", "lanche", "cafe", "restaurante", "ifood", "uber eats", "glovo", "bolt food", "pizza", "hamburg", "padaria", "pastelaria", "bar", "gelado", "sorvete", "pequeno-almoco"),
        "Hábitos" to listOf("cigarro", "tabaco", "maco", "vape", "raspadinha", "aposta", "euromilhoes", "cerveja", "bebida"),
        "Transporte" to listOf("uber", "bolt", "gasolina", "gasoleo", "combustivel", "posto", "autocarro", "onibus", "metro", "comboio", "cp ", "estacionamento", "portagem", "pedagio", "oficina", "via verde"),
        "Moradia" to listOf("aluguel", "renda", "condominio", "luz", "energia", "edp", "agua", "gas", "internet", "meo", "nos ", "vodafone", "reforma"),
        "Saúde" to listOf("farmacia", "remedio", "medicamento", "medico", "consulta", "exame", "ginasio", "academia", "dentista"),
        "Lazer" to listOf("cinema", "concerto", "show", "viagem", "netflix", "spotify", "hbo", "disney", "jogo", "passeio", "festa"),
        "Educação" to listOf("curso", "livro", "escola", "faculdade", "universidade", "propina", "apostila", "formacao")
    )
    private val regrasReceita = listOf(
        SALARIO to listOf("salario", "ordenado", "vencimento"),
        "Reembolso" to listOf("reembolso", "devolveu", "devolucao", "estorno"),
        "Rendimentos" to listOf("juros", "rendimento", "dividendo", "cashback")
    )

    val todas: List<String> = regras.map { it.first } + listOf(FIXAS, OUTROS)
    val receitas: List<String> = regrasReceita.map { it.first } + listOf(EXTRA)

    private fun normalizar(s: String): String =
        Normalizer.normalize(" " + s.lowercase() + " ", Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    fun detectar(descricao: String, receita: Boolean = false): String {
        val d = normalizar(descricao)
        val lista = if (receita) regrasReceita else regras
        for ((cat, palavras) in lista) if (palavras.any { d.contains(it) }) return cat
        return if (receita) EXTRA else OUTROS
    }
}

/** Preferências deste aparelho (não sincronizam). */
object Ajustes {
    private fun p(ctx: Context) = ctx.getSharedPreferences("financas", Context.MODE_PRIVATE)

    fun nome(ctx: Context): String = p(ctx).getString("nome", "Eu") ?: "Eu"
    fun salvarNome(ctx: Context, nome: String) { p(ctx).edit().putString("nome", nome.ifBlank { "Eu" }).commit() }

    fun moeda(ctx: Context): String = p(ctx).getString("moeda", "EUR") ?: "EUR"
    fun salvarMoeda(ctx: Context, codigo: String) {
        val c = if (codigo == "BRL") "BRL" else "EUR"
        p(ctx).edit().putString("moeda", c).commit()
        Formato.codigo = c
    }

    fun notifAtiva(ctx: Context): Boolean = p(ctx).getBoolean("notif", false)
    fun definirNotifAtiva(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("notif", v).commit() }
    fun agitarAtivo(ctx: Context): Boolean = p(ctx).getBoolean("agitar", false)
    fun definirAgitar(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("agitar", v).commit() }

    /** 0 = pouco sensível (agitar forte), 1 = normal, 2 = muito sensível. */
    fun sensibilidade(ctx: Context): Int = p(ctx).getInt("sens", 1)
    fun definirSensibilidade(ctx: Context, v: Int) { p(ctx).edit().putInt("sens", v.coerceIn(0, 2)).commit() }

    fun conquistasVistas(ctx: Context): JSONArray = try { JSONArray(p(ctx).getString("conquistas", "[]")) } catch (e: Exception) { JSONArray() }
    fun marcarConquista(ctx: Context, id: String) {
        val arr = conquistasVistas(ctx)
        for (i in 0 until arr.length()) if (arr.getString(i) == id) return
        arr.put(id)
        p(ctx).edit().putString("conquistas", arr.toString()).commit()
    }
}

/** Operações do app sobre os registros. Toda mudança agenda uma sincronização. */
object Armazem {
    private fun b(ctx: Context) = Banco.de(ctx)
    fun eu(ctx: Context): String = Sessao.eu(ctx)

    private fun novo(ctx: Context, tipo: String, sh: Boolean, dados: JSONObject): String {
        val id = Banco.novoId()
        b(ctx).salvar(Reg(id, tipo, eu(ctx), sh, dados))
        Nuvem.agendar(ctx)
        return id
    }

    private fun alterar(ctx: Context, id: String, bloco: (Reg) -> Reg?) {
        val r = b(ctx).um(id) ?: return
        if (r.dono != eu(ctx)) return   // só o dono altera o que é seu
        bloco(r)?.let { b(ctx).salvar(it); Nuvem.agendar(ctx) }
    }

    fun apagar(ctx: Context, id: String) = alterar(ctx, id) { it.copy(apagado = true) }
    fun restaurar(ctx: Context, id: String) = alterar(ctx, id) { it.copy(apagado = false) }

    // ---------- Lançamentos ----------
    private fun paraLanc(r: Reg): Lanc {
        val o = r.dados
        val rec = o.optString("t") == "r"
        val d = o.optString("d")
        return Lanc(r.id, o.optLong("q"), o.optDouble("v", 0.0), d, o.optString("c").ifEmpty { Categorias.detectar(d, rec) }, rec, r.sh, r.dono, o.optString("cf"))
    }

    fun lancamentos(ctx: Context): List<Lanc> = b(ctx).todos("lanc").map { paraLanc(it) }.sortedByDescending { it.q }

    private fun dadosLanc(g: Gasto) = JSONObject().put("q", g.quando).put("v", g.valor).put("d", g.descricao)
        .put("c", g.categoria).put("t", if (g.receita) "r" else "d")

    fun adicionar(ctx: Context, g: Gasto, sh: Boolean = false): String = novo(ctx, "lanc", sh, dadosLanc(g))

    fun editar(ctx: Context, id: String, g: Gasto, sh: Boolean) {
        val r = b(ctx).um(id) ?: return
        if (r.dono != eu(ctx)) return
        val dados = dadosLanc(g)
        r.dados.optString("cf").takeIf { it.isNotEmpty() }?.let { dados.put("cf", it) }
        if (r.sh && !sh) {
            // Deixar de compartilhar: o registro antigo é apagado (o parceiro recebe a remoção) e nasce um privado
            b(ctx).salvar(r.copy(apagado = true))
            b(ctx).salvar(Reg(Banco.novoId(), "lanc", r.dono, false, dados))
        } else b(ctx).salvar(r.copy(sh = sh, dados = dados))
        Nuvem.agendar(ctx)
    }

    fun duplicar(ctx: Context, id: String) {
        val l = b(ctx).um(id)?.let { paraLanc(it) } ?: return
        adicionar(ctx, Gasto(System.currentTimeMillis(), l.v, l.d, l.c, l.receita), l.sh && l.dono == eu(ctx))
    }

    fun mudarCategoria(ctx: Context, id: String, c: String) = alterar(ctx, id) { it.copy(dados = JSONObject(it.dados.toString()).put("c", c)) }

    private fun inicio(): Long = Datas.inicioDoMes()
    fun gastosDoMes(ctx: Context): List<Lanc> = lancamentos(ctx).filter { it.q >= inicio() && !it.receita }
    fun receitasDoMes(ctx: Context): Double = lancamentos(ctx).filter { it.q >= inicio() && it.receita }.sumOf { it.v }
    fun totalDoMes(ctx: Context): Double = gastosDoMes(ctx).sumOf { it.v }

    // ---------- Curtidas e comentários (cada um é dono dos seus) ----------
    fun curtidas(ctx: Context): List<Reg> = b(ctx).todos("curtida")
    fun comentarios(ctx: Context): List<Reg> = b(ctx).todos("coment")

    fun curtir(ctx: Context, alvo: String) {
        val me = eu(ctx)
        val minha = b(ctx).todos("curtida").firstOrNull { it.dono == me && it.dados.optString("alvo") == alvo }
        if (minha != null) apagar(ctx, minha.id)
        else novo(ctx, "curtida", compartilhadoDe(ctx, alvo), JSONObject().put("alvo", alvo))
    }

    fun comentar(ctx: Context, alvo: String, texto: String) {
        novo(ctx, "coment", compartilhadoDe(ctx, alvo), JSONObject().put("alvo", alvo).put("t", texto)
            .put("a", Ajustes.nome(ctx)).put("q", System.currentTimeMillis()))
    }

    /** Interações num item compartilhado também são visíveis ao casal. */
    private fun compartilhadoDe(ctx: Context, alvo: String) = b(ctx).um(alvo)?.sh ?: false

    // ---------- Contas fixas (a pagar e entradas) ----------
    fun contas(ctx: Context): List<ContaFixa> = b(ctx).todos("conta").map {
        val o = it.dados
        ContaFixa(it.id, o.optString("n"), o.optDouble("v"), o.optInt("dia", 1), o.optBoolean("e"), it.sh, it.dono)
    }.sortedBy { it.dia }

    fun adicionarConta(ctx: Context, nome: String, valor: Double, dia: Int, entrada: Boolean, sh: Boolean) {
        novo(ctx, "conta", sh, JSONObject().put("n", nome).put("v", valor).put("dia", dia).put("e", entrada))
    }

    private fun pagoDoMes(ctx: Context, contaId: String): Reg? {
        val mes = Datas.mesAtual()
        return b(ctx).todos("pago").firstOrNull { it.dados.optString("conta") == contaId && it.dados.optString("mes") == mes }
    }

    fun estaPaga(ctx: Context, contaId: String): Boolean = pagoDoMes(ctx, contaId) != null
    fun quemPagou(ctx: Context, contaId: String): String? = pagoDoMes(ctx, contaId)?.dono

    /** Marcar como paga (ou recebida) cria o lançamento correspondente, visível como a conta. */
    fun alternarPaga(ctx: Context, contaId: String): Boolean {
        val c = contas(ctx).firstOrNull { it.id == contaId } ?: return false
        val pago = pagoDoMes(ctx, contaId)
        if (pago != null) {
            if (pago.dono != eu(ctx)) return false   // quem marcou é quem pode desmarcar
            apagar(ctx, pago.id)
            val inicio = inicio()
            b(ctx).todos("lanc").firstOrNull { it.dono == eu(ctx) && it.dados.optString("cf") == contaId && it.dados.optLong("q") >= inicio }
                ?.let { apagar(ctx, it.id) }
            return true
        }
        novo(ctx, "pago", c.sh, JSONObject().put("conta", contaId).put("mes", Datas.mesAtual()))
        val d = JSONObject().put("q", System.currentTimeMillis()).put("v", c.valor).put("d", c.nome).put("cf", contaId)
        if (c.entrada) d.put("t", "r").put("c", Categorias.detectar(c.nome, true)) else d.put("t", "d").put("c", Categorias.FIXAS)
        novo(ctx, "lanc", c.sh, d)
        return true
    }

    // ---------- Destinos: juntar (meta) ou amortizar (imprevisto) ----------
    fun metas(ctx: Context): List<Meta> {
        val aportes = b(ctx).todos("aporte").groupBy { it.dados.optString("meta") }
        return b(ctx).todos("meta").map { r ->
            val o = r.dados
            Meta(r.id, o.optString("n"), o.optDouble("alvo"), o.optString("e", "🎯"), o.optString("tipo", "j"), r.sh, r.dono,
                maxOf(0.0, aportes[r.id]?.sumOf { it.dados.optDouble("v", 0.0) } ?: 0.0))
        }
    }

    fun adicionarMeta(ctx: Context, nome: String, alvo: Double, emoji: String, tipo: String, sh: Boolean) {
        novo(ctx, "meta", sh, JSONObject().put("n", nome).put("alvo", alvo).put("e", emoji).put("tipo", if (tipo == "a") "a" else "j"))
    }

    /** Cada aporte é um registro de quem guardou: assim os dois podem contribuir para um destino do casal. */
    fun aportar(ctx: Context, metaId: String, valor: Double, trocaId: String = ""): Boolean {
        val m = b(ctx).um(metaId)?.takeIf { !it.apagado } ?: return false
        val d = JSONObject().put("meta", metaId).put("v", valor).put("q", System.currentTimeMillis())
        if (trocaId.isNotEmpty()) d.put("troca", trocaId)
        novo(ctx, "aporte", m.sh, d)
        return true
    }

    fun removerMeta(ctx: Context, id: String) = apagar(ctx, id)

    // ---------- Referências (pessoais) e trocas ----------
    fun referencias(ctx: Context): List<Reg> {
        val me = eu(ctx)
        val minhas = b(ctx).todos("ref").filter { it.dono == me }
        if (minhas.isEmpty() && !b(ctx).existeTipoDoDono("ref", me)) {
            // primeira vez: começa com o café da manhã como referência
            novo(ctx, "ref", false, JSONObject().put("n", "Café da manhã").put("e", "☕").put("v", 3.5).put("dest", true).put("evitar", false).put("m", ""))
            return b(ctx).todos("ref").filter { it.dono == me }
        }
        return minhas
    }

    fun salvarReferencia(ctx: Context, id: String, nome: String, emoji: String, valor: Double, destaque: Boolean, evitar: Boolean, meta: String) {
        val d = JSONObject().put("n", nome).put("e", emoji).put("v", valor).put("dest", destaque).put("evitar", evitar).put("m", meta)
        val r = if (id.isNotEmpty()) b(ctx).um(id) else null
        if (r != null && r.dono == eu(ctx)) { b(ctx).salvar(r.copy(dados = d)); Nuvem.agendar(ctx) }
        else novo(ctx, "ref", false, d)
    }

    fun paraEvitar(ctx: Context): List<Reg> = referencias(ctx).filter { it.dados.optBoolean("evitar") }

    fun trocas(ctx: Context): List<Reg> = b(ctx).todos("troca").filter { it.dono == eu(ctx) }

    /** "Evitei": a troca fica privada; o valor entra no destino como aporte (visível se o destino for do casal). */
    fun registrarTroca(ctx: Context, refId: String): String? {
        val r = b(ctx).um(refId)?.takeIf { !it.apagado } ?: return null
        val o = r.dados
        val v = o.optDouble("v", 0.0)
        val metaId = o.optString("m")
        val meta = metas(ctx).firstOrNull { it.id == metaId }
        val trocaId = novo(ctx, "troca", false, JSONObject().put("q", System.currentTimeMillis()).put("r", refId).put("v", v)
            .put("n", o.optString("n")).put("e", o.optString("e")).put("m", meta?.id ?: ""))
        if (meta != null) aportar(ctx, meta.id, v, trocaId)
        val destino = meta?.let { (if (it.tipo == "a") " abatido em " else " para ") + it.nome } ?: " poupado"
        return "Evitou ${o.optString("e")} ${o.optString("n")}: ${Formato.moeda(v)}$destino"
    }

    /** Apagar ou restaurar uma troca leva junto o aporte que ela gerou. */
    fun apagarTroca(ctx: Context, id: String, restaurarEla: Boolean) {
        if (restaurarEla) restaurar(ctx, id) else apagar(ctx, id)
        val me = eu(ctx)
        Banco.de(ctx).todosComApagados("aporte")
            .filter { it.dono == me && it.dados.optString("troca") == id }
            .forEach { if (restaurarEla) restaurar(ctx, it.id) else apagar(ctx, it.id) }
    }
}

object Datas {
    fun inicioDoMes(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun mesAtual(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    fun diaHoje(): Int = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    fun diasNoMes(): Int = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH)

    /** Dia de vencimento efetivo (conta no dia 31 vence no último dia em meses curtos). */
    fun diaEfetivo(dia: Int): Int = minOf(dia, diasNoMes())
}

/** Números do mês para a notificação (considera tudo o que esta pessoa vê). */
object Previsao {
    data class Resultado(val jaGasto: Double, val receitas: Double, val livre: Double)

    fun doMes(ctx: Context): Resultado {
        val jaGasto = Armazem.totalDoMes(ctx)
        val receitas = Armazem.receitasDoMes(ctx)
        return Resultado(jaGasto, receitas, receitas - jaGasto)
    }

    /** Contas a pagar ainda em aberto neste mês, com dias até o vencimento (negativo = atrasada). */
    fun proximasContas(ctx: Context): List<Pair<ContaFixa, Int>> {
        val hoje = Datas.diaHoje()
        return Armazem.contas(ctx)
            .filter { !it.entrada && !Armazem.estaPaga(ctx, it.id) }
            .map { it to (Datas.diaEfetivo(it.dia) - hoje) }
            .sortedBy { it.second }
    }
}

/** Entende "5,50 café", "mercado 45,90", "1.250,00 renda" e "+1090 salário" (o + indica entrada). */
object Interpretador {
    private val numero = Regex("""\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?(?!\d)|\d+(?:[.,]\d{1,2})?(?!\d)""")
    private val milhar = Regex("""\d{1,3}(?:\.\d{3})+""")
    private val simbolos = Regex("""(?i)r\$|€|\beuros?\b|\beur\b|\breais\b""")

    fun paraNumero(s: String): Double? {
        var x = s.trim().replace(simbolos, "").trim()
        if (x.contains(',')) x = x.replace(".", "").replace(',', '.')
        else if (milhar.matches(x)) x = x.replace(".", "")
        return x.toDoubleOrNull()
    }

    fun interpretar(texto: String, forcarReceita: Boolean = false): Gasto? {
        var t = texto.trim()
        var receita = forcarReceita
        if (t.startsWith("+")) { receita = true; t = t.substring(1).trim() }
        val m = numero.find(t) ?: return null
        val valor = paraNumero(m.value) ?: return null
        if (valor <= 0) return null
        val desc = t.removeRange(m.range).replace(simbolos, "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { if (receita) "Entrada" else "Sem descrição" }
        return Gasto(System.currentTimeMillis(), valor, desc, Categorias.detectar(desc, receita), receita)
    }
}

object Formato {
    /** Moeda atual; carregada ao iniciar o app (AppFinancas) e ao mudar nos ajustes. */
    @Volatile var codigo: String = "EUR"

    private fun local(): Locale = if (codigo == "BRL") Locale("pt", "BR") else Locale("pt", "PT")

    fun moeda(v: Double): String = NumberFormat.getCurrencyInstance(local()).apply {
        currency = Currency.getInstance(codigo)
    }.format(v)

    fun prazo(dias: Int): String = when {
        dias < 0 -> "atrasada ${-dias} dia(s)"
        dias == 0 -> "vence hoje"
        dias == 1 -> "vence amanhã"
        else -> "vence em $dias dias"
    }

    /** Traduz dinheiro nas referências que a pessoa escolheu destacar. */
    fun equivalencia(ctx: Context, valor: Double): String =
        Armazem.referencias(ctx).map { it.dados }
            .filter { it.optBoolean("dest") && it.optDouble("v", 0.0) > 0 }
            .take(2)
            .joinToString(" · ") { String.format(local(), "%.1f× %s %s", valor / it.optDouble("v"), it.optString("e"), it.optString("n")) }
}
