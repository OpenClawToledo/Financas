package com.pessoal.financas

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notificacao {
    private const val CANAL = "lancamento_rapido"
    private const val ID = 1
    const val CHAVE_TEXTO = "texto_gasto"
    const val ACAO_ADICIONAR = "com.pessoal.financas.ADICIONAR"

    private fun criarCanal(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val canal = NotificationChannel(CANAL, "Lançamento rápido", NotificationManager.IMPORTANCE_LOW)
        canal.setShowBadge(false)
        nm.createNotificationChannel(canal)
    }

    /** Notificação fixa com campo de texto: digite "45 mercado" sem abrir o app. */
    fun mostrar(ctx: Context, mensagem: String? = null) {
        criarCanal(ctx)
        val total = Armazem.totalDoMes(ctx)

        val entrada = RemoteInput.Builder(CHAVE_TEXTO).setLabel("Ex: 45 mercado").build()
        val intentAdd = Intent(ctx, ReceptorGasto::class.java).setAction(ACAO_ADICIONAR)
        val piAdd = PendingIntent.getBroadcast(
            ctx, 1, intentAdd,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        val acao = Notification.Action.Builder(
            Icon.createWithResource(ctx, R.drawable.ic_add), "Adicionar gasto", piAdd
        ).addRemoteInput(entrada).build()

        val piAbrir = PendingIntent.getActivity(
            ctx, 2, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val equiv = Formato.equivalencia(ctx, total)
        val texto = mensagem ?: if (equiv.isNotEmpty()) "= $equiv" else "Toque em Adicionar gasto"

        val n = Notification.Builder(ctx, CANAL)
            .setSmallIcon(R.drawable.ic_add)
            .setContentTitle("Este mês: " + Formato.moeda(total))
            .setContentText(texto)
            .setStyle(Notification.BigTextStyle().bigText(texto))
            .setContentIntent(piAbrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(acao)
            .build()

        ctx.getSystemService(NotificationManager::class.java).notify(ID, n)
    }
}

class ReceptorGasto : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val texto = RemoteInput.getResultsFromIntent(intent)
            ?.getCharSequence(Notificacao.CHAVE_TEXTO)?.toString()
        val g = texto?.let { Interpretador.interpretar(it) }
        val msg = if (g != null) {
            Armazem.adicionar(ctx, g)
            val equiv = Formato.equivalencia(ctx, g.valor)
            "✓ ${Formato.moeda(g.valor)} ${g.descricao}" + if (equiv.isNotEmpty()) " = $equiv" else ""
        } else {
            "Não entendi. Use algo como: 45 mercado"
        }
        // Sempre republica, senão a notificação fica "carregando"
        Notificacao.mostrar(ctx, msg)
    }
}
